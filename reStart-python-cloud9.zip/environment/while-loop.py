import random
print("Welcome to guess the number!")
print("The rules are simple. I will think of a numbe, and you will try to guess it")

number = random.randint(1,10)

isGuessRight = False

while isGuessRight != True:
    guess = input("Guess a number between 1 and 10: ")
    if int(guess) == number:
        print("you guessed {}. That is correct! You win!".format(guess))
        isGuessRight = True
    else:
        print("You guessed{}. sorry, that isn't it. Try agan".format(guess))
        
#if the user has not guessed the correct answer, enter the loop
#Ask the user the correct number
#if the correct user guess, tell the user it was the correct guess and exit the loop
#if the wrog guess, tell the user it was the worng guess and continue looop
